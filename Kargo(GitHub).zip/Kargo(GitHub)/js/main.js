$(document).ready(function () {
    
    $('.feedback__slider').slick({
        infinite: false,
        slidesToShow: 1,
        slidesToScroll: 1,
        speed: 1500
      });

   
})